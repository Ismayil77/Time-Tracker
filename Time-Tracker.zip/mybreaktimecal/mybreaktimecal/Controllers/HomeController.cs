﻿using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using System;
using System.Globalization;
using System.IO;

namespace mybreaktimecals.Controllers
{
    public class HomeController : Controller
    {
        [HttpPost("Home/SaveTime")]
        public IActionResult SaveTime([FromBody] TimeEntry entry)
        {
            string directoryPath = @"D:\Mybreaktime";
            string filePath = Path.Combine(directoryPath, "TimeTracking.xlsx");

            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }

            FileInfo fileInfo = new FileInfo(filePath);

            using (ExcelPackage package = new ExcelPackage(fileInfo))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Count == 0 ?
                    package.Workbook.Worksheets.Add("TimeTracking") : package.Workbook.Worksheets[0];

                if (worksheet.Dimension == null)
                {
                    worksheet.Cells[1, 1].Value = "Day";
                    worksheet.Cells[1, 2].Value = "Start Time";
                    worksheet.Cells[1, 3].Value = "End Time";
                    worksheet.Cells[1, 4].Value = "Time (minutes)";
                }

                int row = worksheet.Dimension?.Rows + 1 ?? 2; 

                worksheet.Cells[row, 1].Value = entry.Date;
                worksheet.Cells[row, 2].Value = entry.StartTime; 
                worksheet.Cells[row, 3].Value = entry.EndTime;  
                worksheet.Cells[row, 4].Value = double.Parse(entry.Duration); 

                package.Save();
            }

            return Ok(new { Message = "Time entry saved successfully" });
        }

        [HttpGet]
        public IActionResult GetTimeSpentToday()
        {
            string directoryPath = @"D:\Mybreaktime";
            string filePath = Path.Combine(directoryPath, "TimeTracking.xlsx");

            if (!System.IO.File.Exists(filePath))
            {
                return Ok(new { TimeSpent = 0 });
            }

            using (var package = new ExcelPackage(new FileInfo(filePath)))
            {
                var worksheet = package.Workbook.Worksheets[0];
                var rowCount = worksheet.Dimension.Rows;
                var today = DateTime.Today.ToString("M/d/yyyy");
                double totalTimeSpent = 0;
                for (int row = 2; row <= rowCount; row++)
                {
                    var date = worksheet.Cells[row, 1].Text;
                    var timeSpentText = worksheet.Cells[row, 4].Text;

                    if (date == today && double.TryParse(timeSpentText, out double timeSpent))
                    {
                        totalTimeSpent += timeSpent;
                    }
                }
                return Ok(new { TimeSpent = totalTimeSpent });
            }
        }

        public IActionResult Index()
        {
            return View();
        }
    }

    public class TimeEntry
    {
        public string Date { get; set; }
        public string StartTime { get; set; } 
        public string EndTime { get; set; }   
        public string Duration { get; set; }  
    }


}
